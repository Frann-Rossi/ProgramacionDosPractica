// Clase generica Almacen que implementa la interfaz Contenedor.
// Almacen es generico y puede manejar cualquier tipo de dato (T).
class Almacen<T> implements Almacenable<T> {
    // Un arreglo para almacenar los elementos del tipo T.
    private T[] elementos;
    private int indice;

    // Constructor que recibe el tamaño del almacen. Usamos casteo para crear un arreglo generico.
    // El constructor inicializa un arreglo de tipo generico T[] que almacenara los elementos.
    @SuppressWarnings("unchecked")// y esto? (ver comentarios al final de la clase)
    public Almacen(int tamaño) {
        // Creamos un arreglo del tipo Object y lo casteamos a T[].
        elementos = (T[]) new Object[tamaño];
        indice = 0;
    }

    // Metodo para agregar un elemento al almacen.
    @Override
    public void agregar(T elemento) {
        if (indice < elementos.length) {
            elementos[indice] = elemento;  // guardamos el elemento en el arreglo.
            indice++;  // incrementamos el indice.
        } else {
            System.out.println("El almacen está lleno.");
        }
    }

    // Metodo para obtener un elemento del almacen por su índice.
    @Override
    public T obtener(int indice) {
        if (indice >= 0 && indice < this.indice) {
            return elementos[indice];  // Devolvemos el elemento en el índice solicitado.
        } else {
            System.out.println("Índice fuera de rango.");
            return null;
        }
    }

    // Metodo generico para intercambiar dos elementos del almacen.
    // Aqui <U> es un parametro de tipo generico que no esta relacionado con T.
    public <U> void intercambiar(U[] array, int i, int j) {
        U temp = array[i];  // Guardamos temporalmente el elemento en la posicion i.
        array[i] = array[j];  // Movemos el elemento en j a la posicion i.
        array[j] = temp;  // Asignamos el elemento temporal en la posicion j.
    }
}
/*La línea @SuppressWarnings("unchecked") es una anotación que indica al compilador que ignore ciertas
advertencias relacionadas con la conversión de tipos (también conocido como casting/casteo) inseguro.
En este caso, la advertencia que se esta evitando es una de tipo "unchecked", que sucede cuando hacemos
una conversión (o casting) que el compilador no puede verificar completamente en tiempo de compilacion.

en esta linea: "elementos = (T[]) new Object[tamaño];"

Este tipo de conversion me va a generar una advertencia porque Java no permite crear directamente arreglos
de tipos genéricos (T[]).

Los genericos en Java son "type-erased", o sea que la información de tipos genericos solo se usa en tiempo
de compilacion, pero se elimina o "borra"(por eso "type-erased"), en tiempo de ejecución (porque?).

Entonces:

No se puede crear un arreglo generico directamente: La información del tipo genérico T no está disponible
en tiempo de ejecucion, así que no es seguro crear un arreglo de tipo T[] directamente.

Casting inseguro: Al hacer el casting de (T[]) a un arreglo de Object[], el compilador no puede verificar
si realmente es seguro tratarlo como un arreglo de T[]. Esto provoca una advertencia de tipo "unchecked"
(porque el compilador no puede comprobar si el casting es valido o no).

Y en definitiva, por todo esto es que le voy a indicar al compilador, que ignore la advertencia ya que estoy
seguro de lo que estoy haciendo (estoy absolutamente convencido de que el casting es seguro y no va a causar
problemas en tiempo de ejecucion)

*/


