// Atencion: La letra T representa el tipo de datos que manejara la interface.
interface Almacenable<T>
{/*Esta interfaz define dos metodos: agregar y obtener. Los metodos trabajan
con un tipo genérico T, que sera definido cuando implementemos o utilicemos la interfaz.*/

    // Metodo para agregar un elemento al contenedor.
    void agregar(T elemento);

    // Metodo para obtener un elemento del contenedor.
    T obtener(int indice);
}