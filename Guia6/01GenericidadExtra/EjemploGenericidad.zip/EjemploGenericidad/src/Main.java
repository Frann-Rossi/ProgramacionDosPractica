
/*Ejercicio (ejemplo): vamos a implementar un mini sistema de almacenamiento generico. Tendremos
una clase Almacen que sera generica y nos permitira almacenar objetos de cualquier tipo.
Ademas, implementaremos una interfaz Almacenable que tambien sera generica para representar el
comportamiento basico de cualquier tipo de Almacenable (ej: productos).*/


// Clase principal (para probar el Almacen generico).
public class Main {
    public static void main(String[] args) {
        // Creamos un Almacen para Strings con capacidad para 3 elementos.
        Almacen<String> almacenDeStrings = new Almacen<>(3);
        almacenDeStrings.agregar("san juan");
        almacenDeStrings.agregar("mendoza");
        almacenDeStrings.agregar("san luis");

        // Imprimimos los elementos almacenados.
        System.out.println("Elemento en el índice 0: " + almacenDeStrings.obtener(0));  // printea: san juan
        System.out.println("Elemento en el índice 1: " + almacenDeStrings.obtener(1));  // printea: mendoza
        System.out.println("Elemento en el índice 2: " + almacenDeStrings.obtener(2));  // printea: san luis

        // Creamos un Almacen para enteros con capacidad para 2 elementos.
        Almacen<Integer> almacenDeEnteros = new Almacen<>(2);
        almacenDeEnteros.agregar(100);
        almacenDeEnteros.agregar(200);

        // Imprimimos los elementos almacenados.
        System.out.println("Elemento en el índice 0: " + almacenDeEnteros.obtener(0));  // printea: 100
        System.out.println("Elemento en el índice 1: " + almacenDeEnteros.obtener(1));  // printea: 200

        // Creamos un arreglo de enteros para probar el metodo generico "intercambiar".
        Integer[] numeros = {1, 2, 3};
        System.out.println("Antes de intercambiar: ");
        for (int num : numeros) {
            System.out.print(num + " ");  // Imprime: 1 2 3
        }

        // Intercambiamos los elementos en las posiciones 0 y 2.
        almacenDeEnteros.intercambiar(numeros, 0, 2);

        System.out.println("\nDespues de intercambiar: ");
        for (int num : numeros) {
            System.out.print(num + " ");  // Imprime: 3 2 1
        }
    }
}