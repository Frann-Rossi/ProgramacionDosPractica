import java.util.*;

public class Biblioteca {
    HashMap <String, HashSet<Libro>> biblioteca;

    public Biblioteca() {
        this.biblioteca = new HashMap<>();
    }

    public boolean agregarLibro (Libro l)
    {
        if (!biblioteca.containsKey(l.getGenero()))
            biblioteca.put(l.getGenero(),new HashSet<>());

        return biblioteca.get(l.getGenero()).add(l);

    }

    public int contarLibros ()
    {
        int cantidad = 0;

        for (String genero : biblioteca.keySet())
        {
            cantidad += biblioteca.get(genero).size();
        }
///Metodo 2 (usando iterator)
//        Iterator <Map.Entry<String,HashSet<Libro>>> iterador = biblioteca.entrySet().iterator();
//
//        while (iterador.hasNext())
//        {
//            cantidad += iterador.next().getValue().size();
//        }
        return cantidad;
    }

    public String listarLibros()
    {
        StringBuilder mensaje = new StringBuilder();

        for (String genero : biblioteca.keySet())
        {
            mensaje.append("Genero: "+ genero + '\n');
           for(Libro l : biblioteca.get(genero))
           {
               mensaje.append(l.toString());
           }
        }

        return mensaje.toString();
    }
}
