import java.util.Objects;

public class Libro {
    protected String nombre;
    protected String autor;
    protected String genero;
    protected int cantPaginas;
    protected String isbn;
    protected int nroEdicion;

    public Libro(String nombre, String autor, String genero, int cantPaginas, String isbn, int nroEdicion) {
        this.nombre = nombre;
        this.autor = autor;
        this.genero = genero;
        this.cantPaginas = cantPaginas;
        this.isbn = isbn;
        this.nroEdicion = nroEdicion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public int getCantPaginas() {
        return cantPaginas;
    }

    public void setCantPaginas(int cantPaginas) {
        this.cantPaginas = cantPaginas;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public int getNroEdicion() {
        return nroEdicion;
    }

    public void setNroEdicion(int nroEdicion) {
        this.nroEdicion = nroEdicion;
    }

    @Override
    public boolean equals(Object o) {
        boolean rta = false;
        if (o != null)
            if (o instanceof Libro)
                if (this.getIsbn().equals(((Libro)o).getIsbn()))
                    rta = true;

        return rta;
    }
    @Override
    public int hashCode() {
        return Objects.hash(getIsbn());
    }

    @Override
    public String toString() {
        return "Libro{" +
                "nombre='" + nombre + '\'' +
                ", autor='" + autor + '\'' +
                ", genero='" + genero + '\'' +
                ", cantPaginas=" + cantPaginas +
                ", isbn='" + isbn + '\'' +
                ", nroEdicion=" + nroEdicion +
                '}';
    }
}
