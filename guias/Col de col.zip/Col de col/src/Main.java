import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<Libro> algo = new ArrayList<>();

        System.out.println(algo.get(-5));
    }
}